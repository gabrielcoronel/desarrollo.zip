/*
    Pone el fondo del color correspondiente al estado
    Si esta muerta, lo pone negro, si no, lo pone blanco
*/
const setCellState = (cell, death) => {
    cell.style['background-color'] = death ? 'black' : 'white';
};

/*
    Es el fondo de la celda negro?
    O bien, esta esta celda muerta?
*/
const getCellState = (cell) => {
    return cell.style['background-color'] == 'black';
};

/*
    Genera un valor booleano aleatorio con una probabilidad
    de que salga true del 20%
*/
const generateRandomBoolean = () => {
    // Numero aleatorio del 0 al 5
    const randomIntenger = Math.round(Math.random() * 5);

    // Produce false solo si es un numero en especifico
    if (randomIntenger != 0) {
        return false;
    }

    // De lo contrario, produce true
    return true;
};

/*
    Crea las celdas en la vista y las inicializa aleatoriamente
*/
const DOMinitBoard = () => {
    const board = document.getElementById("board");

    for (let _ = 0; _ < 50 * 50; _++) {
        // Crea una celda
        const cell = document.createElement("div");

        // Le anade una clase para aplicar los estilos
        cell.classList.add("board-cell");

        // Le da un "valor" aleatorio a la celda
        setCellState(cell, generateRandomBoolean());

        // La anade al div del tablero
        board.appendChild(cell);
    }
};

/*
    Reanicia la vista aleatoriamente
*/
const setRandomBoardState = () => {
    const cells = document.getElementById("board").children;

    // Itera sobre todas las celdas y les da valores aleatorios
    for (const cell of cells) {
        setCellState(cell, generateRandomBoolean());
    }
};

const countDeathNeighbors = (cells, cellPosition) => {
    // Banderas convenientes acerca de la posicion de la celda
    const isNotFirstRow = !(cellPosition < 50);
    const isNotLastRow = !(cellPosition > 2449);
    const isNotFirstColumn = !((cellPosition % 50) == 0);
    const isNotLastColumn = !((cellPosition % 50) == 49);

    // Se generan las posiciones candidato solo si estan en
    // las posiciones apropiadas
    const candidates = [
        isNotFirstRow && isNotFirstColumn ? cellPosition - 51 : null,
        isNotFirstRow ? cellPosition - 50 : null,
        isNotFirstRow && isNotLastColumn ? cellPosition - 49 : null,
        isNotFirstColumn ? cellPosition - 1 : null,
        isNotLastColumn ? cellPosition + 1 : null,
        isNotLastRow && isNotFirstColumn ? cellPosition + 49 : null,
        isNotLastRow ? cellPosition + 50 : null,
        isNotLastRow && isNotLastColumn ? cellPosition + 51 : null
    ];

    // Se filtran las posiciones que no son apropiadas y se cuentan
    // las que estan muertas
    return candidates
        .filter((index) => (index !== null) && (cells[index] !== undefined) && getCellState(cells[index]))
        .length;
};

/*
    Actualiza las celdas naturalmente
*/
const cycle = () => {
    // Se obtienene todas las celdas
    const board = document.getElementById("board");
    const cells = board.children;

    for (let i = 0; i < cells.length; i++) {
        // La celda actual
        const currentCell = cells[i];

        // El estado de la celda actual
        const cellState = getCellState(currentCell);

        // La cantidad de vecinos muertos
        const amountDeath = countDeathNeighbors(cells, i);

        if (cellState && (amountDeath != 2) && (amountDeath != 3)) {
            setCellState(currentCell, false);
        } else if (!cellState && (amountDeath == 3)) {
            setCellState(currentCell, true);
        }
    }
};

/*
    Apenas carga la pagina se imprime el tablero
*/
window.addEventListener("load", DOMinitBoard);

/*
    Cuando se hace click en el boton se reinicia aleatoriamente
*/
document.getElementById("start-button")
    .addEventListener("click", setRandomBoardState);

/*
    Se produce un nuevo estado natural cada cuarto de segundo
*/
setInterval(cycle, 250);