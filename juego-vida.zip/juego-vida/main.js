const setCellState = (cell, death) => {
    cell.style['background-color'] = death ? 'black' : 'white';
};

const getCellState = (cell) => {
    return cell.style['background-color'] == 'black';
};

const generateRandomBoolean = () => {
    const randomIntenger = Math.round(Math.random() * 5);

    if (randomIntenger != 0) {
        return false;
    }

    return true;
};

const DOMinitBoard = () => {
    const board = document.getElementById("board");

    for (let _ = 0; _ < 50 * 50; _++) {
        const cell = document.createElement("div");
        cell.classList.add("board-cell");
        setCellState(cell, generateRandomBoolean());

        board.appendChild(cell);
    }
};

const countDeathNeighbors = (cells, cellPosition) => {
    const candidates = [
        cellPosition - 51,
        cellPosition - 50,
        cellPosition - 49,
        cellPosition - 1,
        cellPosition + 1,
        cellPosition + 49,
        cellPosition + 50,
        cellPosition + 51,
    ];

    return candidates
        .filter((index) => (cells[index] != undefined) && (getCellState(cells[index])))
        .length;
};

const cycle = () => {
    const board = document.getElementById("board");
    const cells = board.children;

    for (let i = 0; i < cells.length; i++) {
        const currentCell = cells[i];
        const cellState = getCellState(currentCell);
        const amountDeath = countDeathNeighbors(cells, i);

        if (cellState && (amountDeath != 2) && (amountDeath != 3)) {
            setCellState(currentCell, false);
        } else if (!cellState && (amountDeath == 3)) {
            setCellState(currentCell, true);
        }
    }
};

window.addEventListener("load", DOMinitBoard);
document.getElementById("start-button")
    .addEventListener("click", () => setInterval(cycle, 250));