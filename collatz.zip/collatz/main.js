const calcular = () => {
    let numero = parseInt(document.getElementById("entrada").value);
    let contenido = "";

    while (numero != 1) {
        contenido += numero.toString() + " ";

        if (numero % 2 == 0) numero /= 2;
        else numero = numero * 3 + 1;
    }

    document.getElementById("resultado").textContent = contenido;
};