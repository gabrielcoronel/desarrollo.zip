class Invitado {
    constructor(nombre, comida, conocidos) {
        this.nombre = nombre;
        this.comida = comida;
        this.conocidos = conocidos;
    }
}

class Persona {
    constructor(amigo, nombre, comida) {
        this.amigo = amigo;
        this.nombre = nombre;
        this.comida = comida;
    }
}

class Nodo {
    constructor(amigo, conocidos) {
        this.amigo = amigo;
        this.conocidos = conocidos;
    }
}

ultimoId = "0";

const generarId = () => {
    const siguiente = parseInt(ultimoId) + 1;

    return siguiente.toString();
};

const personas = [];

const insertarElementoAnadirPersona = (referenciaPersona) => {
    const amigoId = generarId();
    const nombreId = generarId();
    const comidaId = generarId();

    const html = `
        <div>
            <label>
                Amigo
                <input type='text' id=${amigoId}>
            </label>

            <label>
                Nombre
                <input type='text' id=${nombreId}>
            </label>

            <label>
                Comida
                <input type='text' id=${comidaId}>
            </label>
        </div>
    `;

    const elemento = document.createElement("div");
    elemento.innerHTML = html;

    document.getElementById("elementos-anadir-personas").appendChild(elemento);

    document.getElementById(nombreId).addEventListener("change", (evento) => {
        referenciaPersona.nombre = evento.target.value;
    });

    document.getElementById(amigoId).addEventListener("change", (evento) => {
        referenciaPersona.amigo = evento.target.value;
    });

    document.getElementById(comidaId).addEventListener("change", (evento) => {
        referenciaPersona.comida = evento.target.value;
    });
};

const diccionarioGlobal = {}

const insertarPersona = () => {
    const amigo = document.getElementById("nombre-amigo").value;
    const nombre = document.getElementById("nombre-conocido").value;
    const comida = parseInt(document.getElementById("comida-conocido").value);

    const persona = new Persona(amigo, nombre, comida);

    if (amigo in diccionarioGlobal) {
        diccionarioGlobal[amigo].push(persona);
    } else {
        diccionarioGlobal[amigo] = [persona];
    }
};

const ordenar = (invitados) => {
    return invitados
        .slice()
        .sort((a, b) => {
            const cocienteA = a.comida / a.conocidos.length;
            const cocienteB = b.comida / b.conocidos.length;

            return cocienteA - cocienteB;
        });
};

const satisfacer = (amigos, invitados) => {
    return amigos.map((amigo) => {
        for (const invitado of invitados) {
            if (invitado.conocidos.includes(amigo)) {
                return invitado;
            }
        }
    });
};

const conseguirAmigos = () => {
    const amigos = Array.from(new Set(personas.map((persona) => persona.amigo)));

    return amigos;
};

const conseguirInvitados = () => {
    const amigos = conseguirAmigos();
    const totalConocidos = ;

    const invitados = amigos.map((amigo) => {
        const conocidos = personas.filter((persona) => persona.amigo == amigo);
    });
    const nodos = amigos.map((amigo) => {

        return new Nodo(amigo, conocidos)
    });

    const conocidos = nodos.reduce((acumulador, nodo) => {
        return acumulador.concat(nodo.conocidos)
    }, []);
    const invitados = [];

    for (const conocido of conocidos) {
        const amigosInvitado = conocidos
            .filter((c) => c.nombre == conocido.nombre)
            .map((c) => c.amigo);

        invitados.push(new Invitado(conocido.nombre, conocido.comida, amigosInvitado));
    }

    return invitados;
};

const analizar = () => {
    const invitados = conseguirInvitados();
    console.log(invitados);
    const amigos = conseguirAmigos();
    console.log(amigos);
    const ordenados = ordenar(invitados);
    console.log(ordenados);
    const satisfechos = satisfacer(amigos, ordenados);
    console.log(satisfechos);

    const html = satisfechos.reduce((a, s) => a + s.nombre + "<br>", "");

    console.log(html)

    document.getElementById("resultado").innerHTML = html;
};