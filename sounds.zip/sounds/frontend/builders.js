// Este archivo contiene funciones correspondientes a una mini librería
// de componentes. Estos "componentes" son funciones que toman un elemento
// (nodo en el DOM) y le insertan otra seria de nodos. Algunos componentes
// toman parámetros adicionales para generar e insertar nodos dinamicamente

// Las funciones correspondientes a los componentes tambien devuelven
// otras funciones para manipular la estructura interna de los componentes
// (leer el valor de los campos, vaciar los campos)

// Campo de un formulario para ingresar categorías
export const buildCategoriesField = (rootElement, initialCategories) => {

    // Se añade un campo de caegtoría por cada categoría inicial
    for (const category of initialCategories) {
        const categoryInputField = document.createElement("input");
        categoryInputField.type = "text";
        categoryInputField.value = category;

        rootElement.appendChild(categoryInputField);
    }

    // Se crea un ícono de suma
    const iconElement = document.createElement("i");
    iconElement.classList.add("fa-solid");
    iconElement.classList.add("fa-plus");

    // Un botón para el ícono de suma
    const addButtonElement = document.createElement("button");
    addButtonElement.type = "button";
    addButtonElement.appendChild(iconElement);

    // Se inserta el componente
    rootElement.appendChild(addButtonElement);
    rootElement.classList.add("categories-field-like");

    // Se le añade un evento al butón con el ícono para añadir
    // una entrada de texto cada vez que se presione
    addButtonElement.addEventListener("click", () => {
        const categoryInputField = document.createElement("input");
        categoryInputField.type = "text";

        rootElement.insertBefore(categoryInputField, addButtonElement);
    });

    // Función que devuelve un vector con todos las categorías ingresadas
    const readCategories = () => {
        const categories = [...rootElement.children]
            .filter((node) => node.tagName == "INPUT" && node.type == "text")
            .map((node) => node.value);

        return categories;
    };

    // Función que vacía todos los campos de las categorías
    const clearCategories = () => {
        [...rootElement.children]
            .filter((node) => node.tagName == "INPUT" && node.type == "text")
            .forEach((node) => node.value = "");
    };

    // Se le da acceso a las funciones al llamante
    return [readCategories, clearCategories];
};

// Fomulario para ingresar o editar pistas
export const buildTrackForm = (
    rootElement,
    submitButtonTextContent,
    initialValues,
    handleSubmit
) => {
    const { title, categories } = initialValues;

    // Se crea un campo para ingresar el título de la pista
    const titleInputElement = document.createElement("input");
    titleInputElement.type = "text";
    titleInputElement.value = title;

    const titleLabelElement = document.createElement("label");
    titleLabelElement.textContent = "Título";
    titleLabelElement.appendChild(titleInputElement);

    // Se crea un input de tipo archivo para obtener el archivo
    // con el audio de la pista
    const audioFileInputElement = document.createElement("input");
    audioFileInputElement.type = "file";
    audioFileInputElement.style.display = "none"; // No se muestra porque es muy feo

    // Icono para el botón que va a activar el input de tipo file
    const audioFileIcon = document.createElement("i");
    audioFileIcon.classList.add("fa-solid");
    audioFileIcon.classList.add("fa-file-audio");

    // Butón que activa el input de tipo file
    const audioFileButtonElement = document.createElement("button");
    audioFileButtonElement.type = "button";
    audioFileButtonElement.appendChild(audioFileIcon);

    // Evento que activa el input de tipo file
    audioFileButtonElement.addEventListener("click", () => {
        audioFileInputElement.click();
    });

    // Campo para las categorías de la pista
    const categoriesFieldElement = document.createElement("div");
    const [readCategories, clearCategories] = buildCategoriesField(categoriesFieldElement, categories);

    // Indicador del campo de las categorías
    const categoriesLabelElement = document.createElement("label");
    categoriesLabelElement.textContent = "Categorías";
    categoriesLabelElement.appendChild(categoriesFieldElement);

    // Botón para realizar la operación dada por el llamante del
    // componente
    const submitButtonElement = document.createElement("button");
    submitButtonElement.type = "submit";
    submitButtonElement.textContent = submitButtonTextContent;

    // El formulario como tal
    const formElement = document.createElement("form");
    formElement.appendChild(titleLabelElement);
    formElement.appendChild(audioFileInputElement);
    formElement.appendChild(audioFileButtonElement);
    formElement.appendChild(categoriesLabelElement);
    formElement.appendChild(submitButtonElement);
    formElement.classList.add("track-form-like");

    // Función que devuelve un objeto que asocia las campos
    // del formulario con sus valores
    const readFields = () => {
        const title = titleInputElement.value;
        const audioFile = audioFileInputElement.files && audioFileInputElement.files[0]
            ? audioFileInputElement.files[0]
            : null;
        const categories = readCategories();

        return {
            title,
            audioFile,
            categories
        };
    };

    // Función que reinicia todos los campos del formulario
    const clearFields = () => {
        titleInputElement.value = "";
        audioFileInputElement.value = "";
        clearCategories();
    };

    // Cuando se sube el formulario se hace la acción indicada
    // por el llamante mediante la función argumento handleSubmit
    formElement.addEventListener("submit", (event) => {
        event.preventDefault();

        // Se le da acceso a las funciones para manipular la
        // estructura del formulario
        handleSubmit(readFields, clearFields)
    });

    // Se inserta el componente
    rootElement.appendChild(formElement);

    // Se le da acceso a las funciones al llamante
    return [readFields, clearFields];
};

// Crea un enlace para el menu
const makeMenuLink = (textContent, url) => {
    // Se crea el contenedor que almacena el enlace
    const containerElement = document.createElement("div");

    containerElement.textContent = textContent;
    containerElement.classList.add("menu-link");

    // Se redirecciona cuando se hace click
    containerElement.addEventListener("click", () => window.location.href = url);

    return containerElement;
};

// El menú
export const buildMenu = (rootElement) => {
    // Se crea un ícono para el logo
    const logoElement = document.createElement("i");
    logoElement.classList.add("fa-solid");
    logoElement.classList.add("fa-music");

    // Se crea el texto del logo
    const logoTitleElement = document.createElement("span");
    logoTitleElement.textContent = "Sounds";

    // El contenedor que almacena al logo
    const logoContainerElement = document.createElement("div");
    logoContainerElement.appendChild(logoElement);
    logoContainerElement.appendChild(logoTitleElement);
    logoContainerElement.classList.add("menu-logo");

    // Se crean los enlaces del menú
    const uploadTrackMenuLinkElement = makeMenuLink("Sube una pista", "/upload-track");
    const allTracksMenuLinkElement = makeMenuLink("Lista de pistas", "/all-tracks");

    // Se crea el contenedor que almacena los enlaces
    const linksContainer = document.createElement("div");
    linksContainer.appendChild(uploadTrackMenuLinkElement);
    linksContainer.appendChild(allTracksMenuLinkElement);
    linksContainer.classList.add("menu-links");

    // Se inserta el componente
    rootElement.appendChild(logoContainerElement);
    rootElement.appendChild(linksContainer);
    rootElement.classList.add("menu");
};