export const buildCategoriesField = (rootElement, initialCategories) => {
    for (const category of initialCategories) {
        const categoryInputField = document.createElement("input");
        categoryInputField.type = "text";
        categoryInputField.value = category;

        rootElement.appendChild(categoryInputField);
    }

    const iconElement = document.createElement("i");
    iconElement.classList.add("fa-solid");
    iconElement.classList.add("fa-plus");

    const addButtonElement = document.createElement("button");
    addButtonElement.type = "button";
    addButtonElement.appendChild(iconElement);

    rootElement.appendChild(addButtonElement);
    rootElement.classList.add("categories-field-like");

    addButtonElement.addEventListener("click", () => {
        const categoryInputField = document.createElement("input");
        categoryInputField.type = "text";

        rootElement.insertBefore(categoryInputField, addButtonElement);
    });

    const readCategories = () => {
        const categories = [...rootElement.children]
            .filter((node) => node.tagName == "INPUT" && node.type == "text")
            .map((node) => node.value);

        return categories;
    };

    return readCategories;
};

export const buildTrackForm = (
    rootElement,
    submitButtonTextContent,
    initialValues,
    handleSubmit
) => {
    const { title, categories } = initialValues;

    const titleInputElement = document.createElement("input");
    titleInputElement.type = "text";
    titleInputElement.value = title;

    const audioFileInputElement = document.createElement("input");
    audioFileInputElement.type = "file";
    audioFileInputElement.style.display = "none";

    const audioFileIcon = document.createElement("i");
    audioFileIcon.classList.add("fa-solid");
    audioFileIcon.classList.add("fa-file-audio");

    const audioFileButtonElement = document.createElement("button");
    audioFileButtonElement.type = "button";
    audioFileButtonElement.appendChild(audioFileIcon);
    audioFileButtonElement.addEventListener("click", () => {
        audioFileInputElement.click();
    });

    const categoriesFieldElement = document.createElement("div");
    const readCategories = buildCategoriesField(categoriesFieldElement, categories);

    const categoriesLabelElement = document.createElement("label");
    categoriesLabelElement.textContent = "Categorías";
    categoriesLabelElement.appendChild(categoriesFieldElement);

    const submitButtonElement = document.createElement("button");
    submitButtonElement.type = "submit";
    submitButtonElement.textContent = submitButtonTextContent;

    const formElement = document.createElement("form");
    formElement.appendChild(titleInputElement);
    formElement.appendChild(audioFileInputElement);
    formElement.appendChild(audioFileButtonElement);
    formElement.appendChild(categoriesLabelElement);
    formElement.appendChild(submitButtonElement);
    formElement.classList.add("track-form-like");

    const readFields = () => {
        const title = titleInputElement.value;
        const audioFile = audioFileInputElement.files && audioFileInputElement.files[0]
            ? audioFileInputElement.files[0]
            : null;
        const categories = readCategories();

        return {
            title,
            audioFile,
            categories
        };
    };

    formElement.addEventListener("submit", (event) => {
        event.preventDefault();

        handleSubmit(readFields)
    });

    rootElement.appendChild(formElement);

    return readFields;
};