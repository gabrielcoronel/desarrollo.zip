export const buildCategoriesField = (rootElement) => {
    const iconElement = document.createElement("i");
    iconElement.classList.add("fa-solid");
    iconElement.classList.add("fa-plus");

    const addButtonElement = document.createElement("button");
    addButtonElement.type = "button";
    addButtonElement.appendChild(iconElement);

    rootElement.appendChild(addButtonElement);

    addButtonElement.addEventListener("click", () => {
        const categoryInputField = document.createElement("input");
        categoryInputField.type = "text";

        rootElement.insertBefore(categoryInputField, addButtonElement);
    });
};

export const buildTrackForm = (rootElement) => {
    const titleInputElement = document.createElement("input");
    titleInputElement.type = "text";

    const audioFileInputElement = document.createElement("input");
    audioFileInputElement.type = "file";

    const audioFileTriggerButton = document.createElement("button");
    audioFileInputElement.classList.add("track-form-choose-audio-file-button");

    const audioFileIcon = document.createElement("i");
    audioFileIcon.classList.add("fa-solid");
    audioFileIcon.classList.add("fa-file-audio");

    const categoriesFieldElement = document.createElement

    const formElement = document.createElement("form");
};