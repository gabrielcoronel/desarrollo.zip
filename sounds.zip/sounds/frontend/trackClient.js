const queryJSON = async (route) => {
    let response = null;

    try {
        response = await fetch(route, {
            method: "GET",
            headers: new Headers({ "Content-Type": "application/json" })
        });
    } catch(error) {
        console.log(error);
        throw error;
    }

    let json = null;

    try {
        json = await response.json();
    } catch (error) {
        console.log(error);
        throw error;
    }

    return json;
};

const mutateJSON = async (route, method, payload) => {
    let response = null;

    try {
        response = await fetch(route, {
            method,
            headers: new Headers({ "Content-Type": "application/json" }),
            body: JSON.stringify(payload)
        });
    } catch (error) {
        console.log(error);
        throw error;
    }

    let json = null;

    try {
        json = await response.json();
    } catch (error) {
        console.log(error);
        throw error;
    }

    return json;
};

const mutateFormData = async (route, method, payload) => {
    try {
        await fetch(route, {
            method,
            body: payload
        });
    } catch (error) {
        console.log(error);
        throw error;
    }
};

const insert = async (track) => {
    await mutateFormData("/api/tracks/", "POST", track);
};

const findAll = async () => {
    const tracks = await queryJSON("/api/tracks/");

    return tracks;
};

const findById = async (id) => {
    const track = await queryJSON(`/api/tracks/${id}`);

    return track;
};

const findByTitleAndCategories = async (title, categories) => {
    const tracks = await mutateJSON(
        `/api/tracks/title-and-categories`,
        "POST",
        { name: title, categories }
    );

    return tracks;
};

const update = async (id, track) => {
    await mutateFormData(`/api/tracks/${id}`, "PUT", track);
};

const remove = async (id) => {
    await mutateJSON(`/api/tracks/${id}`, "DELETE", {});
};

export default {
    insert,
    findById,
    findAll,
    findByTitleAndCategories,
    update,
    remove
};