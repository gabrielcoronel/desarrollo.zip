// Este archivo es el cliente del servicio de
// pistas en el backend. Se encarga de realizar
// solicitudes HTTP al servicio

// Función genérica para hacer una solicitud y parsear
// respuesta en formato JSON
const queryJSON = async (route) => {
    let response = null;

    // Se hace la solicitud y se maneja errores
    try {
        response = await fetch(route, {
            method: "GET",
            headers: new Headers({ "Content-Type": "application/json" })
        });
    } catch(error) {
        console.log(error);
        throw error;
    }

    let json = null;

    // Se parsea la respuesta en formato JSON
    try {
        json = await response.json();
    } catch (error) {
        console.log(error);
        throw error;
    }

    return json;
};

// Función genérica para hacer una mutación mediante la API,
// y enviar y parsear la respuesta en formato JSON
const mutateJSON = async (route, method, payload) => {
    let response = null;

    // Se hace la mutación y se maneja errores
    try {
        response = await fetch(route, {
            method,
            headers: new Headers({ "Content-Type": "application/json" }),
            body: JSON.stringify(payload)
        });
    } catch (error) {
        console.log(error);
        throw error;
    }

    let json = null;

    // Se parsea la respuesta en formato JSON
    try {
        json = await response.json();
    } catch (error) {
        console.log(error);
        throw error;
    }

    return json;
};

// Función genérica para hacer una mutación mediante
// la API y enviar parámetros en formato FormData
const mutateFormData = async (route, method, payload) => {
    try {
        await fetch(route, {
            method,
            body: payload
        });
    } catch (error) {
        console.log(error);
        throw error;
    }
};

// Inserta una nueva pista en la base de datos mediante
// la API
const insert = async (track) => {
    await mutateFormData("/api/tracks/", "POST", track);
};

// Devuelve todas las pistas en la base de datos mendiante
// la API
const findAll = async () => {
    const tracks = await queryJSON("/api/tracks/");

    return tracks;
};

// Devuelve la pista que tenga el id dado mediante la APi
const findById = async (id) => {
    const track = await queryJSON(`/api/tracks/${id}`);

    return track;
};

// Devuelve las pistas que tengan el título y categorías dadas
// mediante la API
const findByTitleAndCategories = async (title, categories) => {
    const tracks = await mutateJSON(
        `/api/tracks/title-and-categories`,
        "POST",
        { title, categories }
    );

    return tracks;
};

// Actualiza los datos de la pista con el id dado
// y los datos en el objeto @track mediante la APi
const update = async (id, track) => {
    await mutateFormData(`/api/tracks/${id}`, "PUT", track);
};

// Elimina una pista de la base de datos mediante la API
const remove = async (id) => {
    await mutateJSON(`/api/tracks/${id}`, "DELETE", {});
};

export default {
    insert,
    findById,
    findAll,
    findByTitleAndCategories,
    update,
    remove
};