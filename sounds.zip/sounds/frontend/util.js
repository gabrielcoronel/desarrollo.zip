export const readCategoriesFromCategoriesField = (categoriesFieldElement) => {
    const categories = [...categoriesFieldElement.children]
        .filter((node) => node.tagName == "INPUT" && node.type == "text")
        .map((node) => node.value);

    return categories;
};