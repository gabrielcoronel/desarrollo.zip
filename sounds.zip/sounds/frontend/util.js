export const formDataFromObject = (object) => {
    const formData = new FormData();

    for (const [key, value] of Object.entries(object)) {
        if (Array.isArray(value)) {
            for (const item of value) {
                formData.append(`${key}[]`, item);
            }
        } else {
            formData.set(key, value);
        }
    }

    return formData;
};