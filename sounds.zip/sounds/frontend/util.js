// Convierte un objeto de JavaScript en un objeto
// FormData
export const formDataFromObject = (object) => {
    const formData = new FormData();

    // Se itera sobre todos los pares de llaves y valores
    for (const [key, value] of Object.entries(object)) {
        if (Array.isArray(value)) {
            // Si el valor es un vector se usa append en lugar
            // de set en cada elemento del vector
            for (const item of value) {
                formData.append(`${key}[]`, item);
            }
        } else {
            formData.set(key, value);
        }
    }

    return formData;
};