const mongoose = require("mongoose");

// El esquema para representar una pista,
// incluye el titulo, un enlace al archivo que
// contiene el audio y un vector de categorias
const schema  = new mongoose.Schema({
    title: String,
    audioUri: String,
    categories: [String]
});

// Se compila el esquema en un modelo
const model = new mongoose.model("Track", schema);

module.exports = model;