const mongoose = require("mongoose");

const schema  = new mongoose.Schema({
    title: String,
    audioUri: String,
    categories: [String]
});

const model = new mongoose.model("Track", schema);

module.exports = model;