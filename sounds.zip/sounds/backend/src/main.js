const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const morgan = require("morgan");

// Variables de entorno
const PORT = 8080;
const MONGODB_CONNECTION_URI
    = "mongodb+srv://gabriel:gabriel@cluster0.caz4i3r.mongodb.net/?retryWrites=true&w=majority";

const app = express();

// Middleware necesario
app.use(bodyParser.json({ limit: "50mb" })); // Parsear JSON
app.use(morgan("tiny")); // Logging de las solicitudes HTTP
app.use("/user-content", express.static("tracks")); // Archivos estáticos de las pistas

// El servicio de las pistas
const trackService = require("./trackService.js");
app.use("/api/tracks", trackService);

// Función conveniente para servir archivos fácilmente
const serveFile = (router, route, root, path) => {
    router.get(route, (_, res) => res.sendFile(path, {
        root: root
    }));
};

serveFile(app, "/lib/track-client", "../frontend", "/trackClient.js"); // cliente de pistas
serveFile(app, "/lib/builders", "../frontend", "/builders.js"); // librería de componentes
serveFile(app, "/lib/util", "../frontend", "/util.js"); // funciones de utilidad
serveFile(app, "/shared/style", "../frontend", "/shared.css"); // CSS compartido entre páginas
serveFile(app, "/upload-track", "../frontend", "/upload-track.html"); // vista para subir pistas
serveFile(app, "/all-tracks", "../frontend", "/all-tracks.html"); // vista de listado y búsqueda de pistas
serveFile(app, "/edit-track", "../frontend", "/edit-track.html"); // vista para actualizar una pista

// Se conecta al base de datos en MongoDB Atlas
mongoose
    .connect(MONGODB_CONNECTION_URI)
    .then(() => console.log("Connected to MongoDB Atlas"))
    .catch((error) => console.error(error));

// Se inicia el servidor en puerto seleccionado
app.listen(PORT, () => console.log(`Server listening in port ${PORT}`));