const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const morgan = require("morgan");

const PORT = 8080;
const MONGODB_CONNECTION_URI
    = "mongodb+srv://gabriel:gabriel@cluster0.caz4i3r.mongodb.net/?retryWrites=true&w=majority";

const app = express();
const trackService = require("./trackService.js");

app.use(bodyParser.json({ limit: "50mb" }));
app.use(morgan("tiny"));
app.use("/user-content", express.static("tracks"));
app.use("/api/tracks", trackService);

const serveFile = (router, route, root, path) => {
    router.get(route, (_, res) => res.sendFile(path, {
        root: root
    }));
};

serveFile(app, "/lib/track-client", "../frontend", "/trackClient.js");
serveFile(app, "/lib/builders", "../frontend", "/builders.js");
serveFile(app, "/lib/util", "../frontend", "/util.js");
serveFile(app, "/upload-track", "../frontend", "/upload-track.html");
serveFile(app, "/all-tracks", "../frontend", "/all-tracks.html");

mongoose
    .connect(MONGODB_CONNECTION_URI)
    .then(() => console.log("Connected to MongoDB Atlas"))
    .catch((error) => console.error(error));

app.listen(PORT, () => console.log(`Server listening in port ${PORT}`));