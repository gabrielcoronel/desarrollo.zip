const express = require("express");
const multer = require("multer");

const trackRepository = require("./trackRepository.js");

const trackService = express.Router();
const upload = multer({ dest: "./tracks" });

trackService.post("/", upload.single("audioFile"), (req, res) => {
    const track = req.body;
    const audioFileName = req.file.filename;
    const audioUri = `http://localhost:8080/user-content/${audioFileName}`;

    trackRepository
        .insert({ ...track, audioUri })
        .catch((error) => res.status(400).send(error));
});

trackService.post("/title-and-categories", (req, res) => {
    const { name, categories } = req.body;

    trackRepository
        .findByTitleAndCategories(name, categories)
        .then((tracks) => res.json(tracks))
        .catch((error) => res.status(400).send(error));
});

trackService.get("/:id", (req, res) =>  {
    const id = req.params.id;

    trackRepository
        .findById(id)
        .then((track) => res.json(track))
        .catch((error) => res.status(400).send(error));
});

trackService.get("/", (_, res) => {
    trackRepository
        .findAll()
        .then((tracks) => res.json(tracks))
        .catch((error) => res.status(400).send(error));
});

trackService.put("/:id", upload.single("audioFile"), (req, res) => {
    const id = req.params.id;
    const track = req.body;

    const updatedTrack = { ...track };

    if (req.file !== undefined) {
        updatedTrack.audioUri
            = `http://localhost:8080/user-content/${req.file.filename}`;
    }

    trackRepository
        .update(id, updatedTrack)
        .catch((error) => res.status(400).send(error));
});

trackService.delete("/:id", (req, res) => {
    const id = req.params.id;

    trackRepository
        .remove(id)
        .catch((error) => res.status(400).send(error));
});

module.exports = trackService;