const express = require("express");
const multer = require("multer");

// Este archivo define el servicio que permite
// interactuar con el repositorio de pistas
// Es decir, expona la API mediante HTTP para interactuar
// con la base de datos mediante el repositorio

// El repositorio a consumir
const trackRepository = require("./trackRepository.js");

// Router que expone el servicio
const trackService = express.Router();

// Middleware para procesar archivo de form-data
const upload = multer({ dest: "./tracks" });

// Ruta post que crea una nueva pista
trackService.post("/", upload.single("audioFile"), (req, res) => {
    const track = req.body;
    const audioFileName = req.file.filename;
    const audioUri = `http://localhost:8080/user-content/${audioFileName}`;

    trackRepository
        .insert({ ...track, audioUri })
        .catch((error) => res.status(400).send(error));
});

// Ruta post que semanticamente corresponde a un get
// Se usa el verbo POST por conveniencia a la hora de
// recibir el parámetro de categorías ya que recibir un
// vector mediante el query-string es incoveniente para
// el frontend

// Devuelve a todas las pistas que "coincidan" con el
// nombre y categorias dados. Lanza el error 404
// si no se encuentra
trackService.post("/title-and-categories", (req, res) => {
    const { title, categories } = req.body;

    trackRepository
        .findByTitleAndCategories(title, categories)
        .then((tracks) => res.json(tracks))
        .catch((error) => res.status(404).send(error));
});

// Devuelve a la pista que tenga el id dado por
// el parámetro de la ruta. Lanza el error 404
// si no se encuentra
trackService.get("/:id", (req, res) =>  {
    const id = req.params.id;

    trackRepository
        .findById(id)
        .then((track) => res.json(track))
        .catch((error) => res.status(404).send(error));
});

// Devuelve a todas las pistas disponibles en el repositorio
trackService.get("/", (_, res) => {
    trackRepository
        .findAll()
        .then((tracks) => res.json(tracks))
        .catch((error) => res.status(400).send(error));
});

// Actualiza a la pista con con id dado por el parámetro
// de la ruta con las datos dados
trackService.put("/:id", upload.single("audioFile"), (req, res) => {
    const id = req.params.id;
    const track = req.body;

    const updatedTrack = { ...track };

    // Si se envía un archivo, se inserta en la base de datos
    if (req.file !== undefined) {
        updatedTrack.audioUri
            = `http://localhost:8080/user-content/${req.file.filename}`;
    }

    trackRepository
        .update(id, updatedTrack)
        .catch((error) => res.status(400).send(error));
});

// Elimina a la pista con el id del parámetro de la ruta
// en el repositorio
trackService.delete("/:id", (req, res) => {
    const id = req.params.id;

    trackRepository
        .remove(id)
        .catch((error) => res.status(400).send(error));
});

module.exports = trackService;