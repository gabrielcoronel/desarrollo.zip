const trackModel = require("./trackModel.js");

// Este archivo es el repositorio de todas las pistas
// es una abstraccion de la logica de negocios de la
// aplicacion sobre los metodos de persistencia de
// mongoose (trackModel)

// Inserta una pista en la coleccion de pistas
const insert = async (track) => {
    await trackModel.create(track);
};

// Encuentra todas las pistas en la coleccion de pistas
const findAll = async () => {
    const tracks = await trackModel.find();
    const reversedTracks = tracks.reverse();

    return reversedTracks;
};

// Encuentra una pista puntual mediante su identificador
// unico en la coleccion de pistas
const findById = async (id) => {
    const track = await trackModel.findById(id);

    return track;
};

// Encuentra las pistas que incluyen (sin considerar mayusculas)
// a @title en su titulo y @categories en sus categorias
const findByTitleAndCategories = async (title, categories) => {
    // Checkea que contenga a @title mediante una expresión regular
    const query = {
        title: {
            $regex: title,
            $options: "i"
        },
    };

    // Si se proveen categorías, checkea que tenga esas categorías
    if (categories.length !== 0) {
        query.categories = {
            $all: categories
        }
    }

    const tracks = await trackModel.find(query);

    return tracks;
};

// Actualiza a la pista con el id @id con los datos
// que tiene el objeto @track
const update = async (id, track) => {
    await trackModel.updateOne({ _id: id }, track);
};

// Elimina a la pista con el id @id
const remove = async (id) => {
    await trackModel.deleteOne({ _id: id });
};

module.exports = {
    insert,
    findAll,
    findById,
    findByTitleAndCategories,
    update,
    remove
};