const trackModel = require("./trackModel.js");

const insert = async (track) => {
    await trackModel.create(track);
};

const findAll = async () => {
    const tracks = await trackModel.find();

    return tracks;
};

const findByTitleAndCategories = async (title, categories) => {
    const query = {
        title: {
            $regex: title,
            $options: "i"
        },
    };

    if (categories.length !== 0) {
        query.categories = {
            $all: categories
        }
    }

    const tracks = await trackModel.find(query);

    return tracks;
};

const update = async (id, track) => {
    await trackModel.updateOne({ _id: id }, track);
};

const remove = async (id) => {
    await trackModel.deleteOne({ _id: id });
};

module.exports = {
    insert,
    findAll,
    findByTitleAndCategories,
    update,
    remove
};