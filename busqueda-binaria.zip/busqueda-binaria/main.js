const vector = new Array(10);

for (let i = 0; i < vector.length; i++) {
    const value = Math.round(Math.random() * 100) + 1;

    vector[i] = value;
}

console.log(vector);

const sortedVector = new Array(10);

for (let i = 0; i < sortedVector.length; i++) {
    let minimumPosition = 0;

    while (vector[minimumPosition] == null) {
        minimumPosition++;
    }

    for (let j = 0; j < vector.length; j++) {
        if (vector[j] == null) {
            continue;
        }

        if (vector[j] < vector[minimumPosition]) {
            minimumPosition = j;
        }
    }

    sortedVector[i] = vector[minimumPosition];
    vector[minimumPosition] = null;
}

console.log(sortedVector);

const searchedNumber = parseInt(prompt("Ingrese el numero a buscar"));

let middlePosition = Math.round((sortedVector.length - 1) / 2);
let startPosition = 0;
let endPosition = sortedVector.length - 1;
let found = false;

while (true) {
    const currentValue = sortedVector[middlePosition];

    if (currentValue == searchedNumber) {
        found = true;
        break;
    }

    if (middlePosition == endPosition) {
        middlePosition = startPosition;
        found = true;
        break;
    }

    if (middlePosition == startPosition) {
        middlePosition = endPosition;
        found = true;
        break;
    }

    if (currentValue > searchedNumber) {
        endPosition = middlePosition;
    } else if (currentValue < searchedNumber) {
        startPosition = middlePosition;
    }

    middlePosition = Math.round((endPosition - startPosition) / 2) + startPosition;
}

if (found) {
    alert(`El numero se encontro en la posicion ${middlePosition}`)
} else {
    alert("El numero no se encontro");
}