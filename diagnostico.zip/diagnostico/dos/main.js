const calcular = () => {
    const valor = document.querySelector("#entrada").value;

    const palabras = valor.split("a");

    document.querySelector("#resultado").innerHTML = palabras.join("<br>");
};