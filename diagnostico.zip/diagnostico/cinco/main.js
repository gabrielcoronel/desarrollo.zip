const foo = () => {
    let v = [];

    for (let i = 1; i <= 100; i++) {
        v.push(i);
    }

    v.forEach(a => console.log(a));
}