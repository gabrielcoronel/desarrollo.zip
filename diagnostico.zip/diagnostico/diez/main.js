class Matriz {
    constructor(cantidad_filas, cantidad_columnas) {
        this.elementos = new Array(cantidad_filas);

        for (let i = 0; i < cantidad_filas; i++) {
            this.elementos[i] = new Array(cantidad_columnas).fill(null);
        }

        this.posicion = 0;
        this.cantidad_filas = cantidad_filas;
        this.cantidad_columnas = cantidad_columnas;
    }

    insertar(elemento) {
        const posicion_fila = Math.floor(this.posicion / this.cantidad_filas);
        const posicion_columna = this.posicion % this.cantidad_columnas;

        this.elementos
            [posicion_fila]
            [posicion_columna] = elemento;

        this.posicion += 1;
    }

    toHTMLString() {
        let string = "";
        
        for (const fila in this.elementos) {
            for (const elemento in fila) {
                if (elemento == null) return string;

                string += `${elemento} `;
            }

            string += "<br>";
        }

        return string;
    }
}

const mostrar = (id) => {
    document.getElementById(id).style.display = null;
};

const ocultar = (id) => {
    document.getElementById(id).style.display = "none";
};

const multiplicarMatrices = (primera, segunda) => {
    const resultado = new Matriz(primera.cantidad_filas, primera.cantidad_columnas);

    for (let i = 0; i < primera.cantidad_filas; i++) {
        for (let j = 0; j < primera.cantidad_columnas; j++) {
            const valor = new Array(primera.cantidad_columnas)
                .map(primera.elementos[i][r + 1] * segunda.elementos[r + 1][j]);

            resultado.elementos[i][j] = valor;
        }
    }

    return resultado;
};

ocultar("rellenado");
ocultar("resultados");

let primeraMatriz = null;
let segundaMatriz = null;

let posicionPrimera = 0;
let posicionSeguna = 0;

const crearMatrices = () => {
    const filas
        = parseInt(document.getElementById("filas").value);

    const columnas
        = parseInt(document.getElementById("columnas").value);

    primeraMatriz = new Matriz(filas, columnas);
    segundaMatriz = new Matriz(filas, columnas);

    ocultar("dimensiones");
    mostrar("rellenado");
};

const anadir = () => {
    const xa = parseInt(document.getElementById("numero-a"));
    const xb = parseInt(document.getElementById("numero-b"));
    const maxima = primeraMatriz.cantidad_columnas * primeraMatriz.cantidad_filas;

    console.log("no");

    if (primeraMatriz.posicion < maxima && xa) {
        primeraMatriz.insertar(parseInt(xa));
    }

    if (segundaMatriz.posicion < maxima && xb) {
        segundaMatriz.insertar(parseInt(xb));
    }

    if (segundaMatriz.posicion >= maxima && primeraMatriz.posicion >= maxima) {
        ocultar("rellenado");
        imprimir_resultados();
        mostrar("resultados")
    }

    document.querySelector("#cuenta-a").textContent
        = `Quedan ${maxima - primeraMatriz.posicion} elementos`;

    document.querySelector("#cuenta-b").textContent
        = `Quedan ${maxima - segundaMatriz.posicion} elementos`;
};

const imprimir_resultados = () => {
    const resultado = multiplicarMatrices(primeraMatriz, segundaMatriz);

    document.getElementById("resultados").innerHTML = resultado.toHTMLString();
};