let matriz = null;
let filas = null;
let columnas = null;
let indice_actual = 0;

const ocultar = (id) => {
    document.getElementById(id).style.display = "none";
};

const mostrar = (id) => {
    document.getElementById(id).style.display = null;
};

ocultar("relleno");
ocultar("resultados");

const crear = () => {
    filas = parseInt(document.querySelector("#filas").value);
    columnas = parseInt(document.querySelector("#columnas").value);

    matriz = generar_matriz(filas, columnas);
    cantidad_elementos = filas * columnas;

    ocultar("dimensiones");
    mostrar("relleno");
};

const generar_matriz = (filas, columnas) => {
    const m = new Array(filas);

    for (let i  = 0; i < filas; i++) {
        m[i] = new Array(columnas);
    }

    return m;
};

const anadir = () => {
    const numero = parseInt(document.querySelector("#numero").value);

    matriz[Math.floor(indice_actual / filas)][indice_actual % columnas] = numero;
    indice_actual++;

    document.querySelector("#cuenta").textContent
        = `Quedan ${filas * columnas - indice_actual} elementos`;

    if (indice_actual == filas * columnas) ocultar("relleno");

    imprimir_resultado()
    mostrar("resultados");
};

const imprimir_resultado = () => {
    let contenido = "Contenidos:<br>";

    for (const fila of matriz) {
        for (const columna of fila) {
            if (columna == null) return;

            contenido += columna.toString() + " ";
        }

        contenido += "<br>";
    }

    document.querySelector("#resultados").innerHTML = contenido;
};