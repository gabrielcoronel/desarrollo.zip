const numeros = [];

const anadir = () => {
    const valor = document.querySelector("#entrada").value;

    numeros.push(valor);

    document.querySelector("#resultados").innerHTML = numeros.join("<br>");
};