const numeros = [];

const anadir = () => {
    const valor = parseInt(document.querySelector("#entrada").value);

    numeros.push(valor);

    console.log(numeros);
    numeros.sort();
    console.log(numeros);

    document.querySelector("#resultados").innerHTML = numeros.join("<br>");
};