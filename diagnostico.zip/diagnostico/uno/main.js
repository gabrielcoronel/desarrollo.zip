const calcular = () => {
    const valor = document.querySelector("#entrada").value;

    document.querySelector("#resultado").textContent = valor.length;
};