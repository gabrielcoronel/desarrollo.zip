const numeros = [];

const anadir = () => {
    const valor = document.querySelector("#entrada").value;

    if (!numeros.includes(valor)) numeros.push(valor);

    document.querySelector("#resultados").innerHTML = numeros.join("<br>");
};