const calcular = () => {
    const valor = document.querySelector("#entrada").value;
    const letra = document.querySelector("#letra").value

    const letras = valor.split("");
    const pos = letras.indexOf(letra)

    const texto = pos != -1 ? pos : "No se encontro";

    document.querySelector("#resultado").innerHTML = texto;
};