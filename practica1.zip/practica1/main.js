const vector = new Array(10);

for (let i = 0; i < 10; i++) {
    vector[i] = Math.round(Math.random() * 100) + 1
}

console.log(vector);

const vectorOrdenado = new Array(10);

for (let i = 0; i < 10; i++) {
    let posicionMenor = 0;

    while (vector[posicionMenor] < 0) {
        posicionMenor += 1;
    }

    for (let j = 0; j < 10; j++) {
        if (vector[j] < 0) {
            continue;
        }

        if (vector[j] < vector[posicionMenor]) {
            posicionMenor = j;
        }
    }

    vectorOrdenado[i] = vector[posicionMenor];
    vector[posicionMenor] = -1;
}

console.log(vectorOrdenado);